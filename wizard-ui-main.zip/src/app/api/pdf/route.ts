import { NextRequest, NextResponse } from "next/server";
import { renderToStream } from "@react-pdf/renderer";
import { BlueprintPDF } from "@/components/PDFDocument";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { blueprint, businessType } = body;

    if (!blueprint || typeof blueprint !== "object") {
      return NextResponse.json(
        { error: "Blueprint data is required" },
        { status: 400 }
      );
    }

    console.log("[PDF API] Generating PDF for:", businessType ?? "general");

    const element = BlueprintPDF({ blueprint, businessType });
    const stream = await renderToStream(element);

    const chunks: Buffer[] = [];
    for await (const chunk of stream) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    const buffer = Buffer.concat(chunks);

    console.log("[PDF API] PDF generated successfully, size:", buffer.length);

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="campaign-blueprint-${businessType ?? "general"}-${new Date().toISOString().slice(0, 10)}.pdf"`,
      },
    });
  } catch (error) {
    console.error("[PDF API] Error generating PDF:", error);
    // أرجع JSON دائماً حتى يستطيع الفرونت إظهار الخطأ بشكل صحيح
    return NextResponse.json(
      { 
        error: "Failed to generate PDF", 
        details: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined 
      },
      { status: 500 }
    );
  }
}