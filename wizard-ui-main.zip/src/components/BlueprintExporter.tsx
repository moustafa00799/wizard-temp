"use client";

import { useState } from "react";
import type { BlueprintData, ProReadyJSON } from "@/lib/blueprint-types";

interface BlueprintExporterProps {
  blueprint: BlueprintData;
  businessType?: string;
  wizardData?: Record<string, unknown>;
}

const LOCAL_SECTION_LABELS: Record<string, string> = {
  executive_summary: "ملخص تنفيذي",
  strategy_summary: "ملخص الاستراتيجية",
  recommended_funnel: "الفانل الموصى به",
  campaign_structure: "هيكل الحملة",
  audience_structure: "هيكل الجمهور",
  budget_split: "توزيع الميزانية",
  creative_angles: "زوايا الإعلانات",
  tracking_checklist: "قائمة التتبع",
  risk_flags: "المخاطر والتحذيرات",
  first_14_days_plan: "خطة أول 14 يوم",
  pre_launch_fixes: "ما يجب إصلاحه قبل الإطلاق",
};

function buildProReadyJSON(
  blueprint: BlueprintData,
  wizardData?: Record<string, unknown>
): ProReadyJSON {
  const bp = blueprint;
  const wz = wizardData ?? {};

  const strategy = bp.strategy_summary;
  const budget = bp.budget_split;
  const audience = bp.audience_structure;
  const creative = bp.creative_angles;
  const tracking = bp.tracking_checklist;
  const riskFlags = bp.risk_flags;
  const plan14 = bp.first_14_days_plan;
  const preLaunch = bp.pre_launch_fixes;
  const exec = bp.executive_summary;

  const dailyBudget = budget?.daily_budget?.value?.recommended ?? 0;
  const totalBudget = dailyBudget * 14;
  const currency = "SAR";

  const channelAlloc = budget?.channel_allocation?.value ?? {};
  const campaignAllocation = Object.entries(channelAlloc).map(
    ([channel, percent]) => ({
      channel,
      amount: Math.round(totalBudget * ((percent as number) / 100)),
      percent: percent as number,
      objective: strategy?.recommended_objective?.value ?? "awareness",
    })
  );

  const week1Tasks =
    plan14?.week_1?.slice(0, 3).map((t, i) => ({
      day: i + 1,
      action: t.task,
      owner: t.owner,
      priority: t.priority as "high" | "medium" | "low",
    })) ?? [];

  const week2Tasks =
    plan14?.week_1?.slice(3).map((t, i) => ({
      day: i + 4,
      action: t.task,
      owner: t.owner,
      priority: t.priority as "high" | "medium" | "low",
    })) ?? [];

  const week3Tasks =
    plan14?.week_2?.map((t, i) => ({
      day: i + 8,
      action: t.task,
      owner: t.owner,
      priority: t.priority as "high" | "medium" | "low",
    })) ?? [];

  return {
    _meta: {
      version: "1.0.0",
      exported_at: new Date().toISOString(),
      exported_by: "Campaign Engine Builder",
      format: "pro-ready-v1",
    },
    campaign_info: {
      campaign_name: `${bp.blueprint_id ?? "campaign"}_pro`,
      business_type: (wz.business_type as string) ?? "unknown",
      industry_vertical: (wz.business_type as string) ?? "unknown",
      created_at: bp.generated_at ?? new Date().toISOString(),
      strategist: "Campaign Engine Builder",
      client_name: (wz.business_type as string) ?? "unknown",
      version: bp.version ?? "1.0.0",
      tags: [(wz.business_type as string) ?? "general", bp.version ?? "v1"],
    },
    objective_hierarchy: {
      primary_objective: strategy?.recommended_objective?.value ?? "awareness",
      secondary_objectives: (wz.secondary_objectives as string[]) ?? [],
      north_star_kpi: (wz.north_star_kpi as string) ?? "sales_count",
      success_metrics: ["roas", "cac", "conversion_rate", "ctr"],
      funnel_stage: strategy?.funnel_type?.value ?? "website_funnel",
      conversion_destination:
        (wz.conversion_destination as string) ?? "website",
    },
    audience_matrix: {
      core_segments: audience?.segments ?? [],
      exclusions: audience?.exclusions ?? [],
      lookalike_plan: audience?.lookalike?.recommended
        ? ["pixel_based_1%", "pixel_based_3%"]
        : [],
      custom_audiences: [],
      geo_targeting: (wz.target_locations as string[]) ?? [],
      language: "ar",
      audience_size_estimate:
        audience?.primary_audience?.size_estimate ?? "unknown",
    },
    budget_breakdown: {
      total_budget: totalBudget,
      currency,
      daily_cap: dailyBudget,
      duration_days: 14,
      campaign_allocation: campaignAllocation,
      day_7_projection: Math.round(totalBudget * 0.5),
      day_14_projection: totalBudget,
      cac_target: budget?.cac_target?.value ?? 0,
      roas_target: 3.0,
      break_even_roas: 1.5,
      budget_flexibility: budget?.daily_budget?.value?.flexible
        ? "flexible"
        : "fixed",
    },
    creative_specs: {
      angles: [
        creative?.primary_angle?.hook ?? "",
        ...(creative?.alternative_angles?.map((a) => a.hook) ?? []),
      ].filter(Boolean),
      primary_hook: creative?.primary_angle?.hook ?? "",
      formats: creative?.formats?.map((f) => f.type) ?? ["image"],
      copy_framework: "AIDA",
      headline_variants: [creative?.primary_angle?.hook ?? ""],
      cta_variants: [creative?.primary_angle?.cta ?? "ابدأ الآن"],
      visual_guidelines: [
        "Brand colors",
        "High contrast",
        "Clear product shot",
      ],
      content_capacity: (wz.content_capacity as string) ?? "slow",
    },
    tracking_config: {
      pixel_status: tracking?.setup_status?.overall ?? "unknown",
      conversion_events: tracking?.required_events ?? [],
      utm_parameters: {
        source: "paid_social",
        medium: "cpc",
        campaign: bp.blueprint_id ?? "default",
      },
      attribution_window: "7d_click_1d_view",
      key_metrics: ["impressions", "clicks", "conversions", "roas", "cac"],
      reporting_dashboard: "meta_ads_manager",
      alert_thresholds: {
        cac: budget?.cac_target?.value
          ? budget.cac_target.value * 1.5
          : 100,
        roas: 1.0,
      },
    },
    launch_sequence: {
      phase: exec?.launch_recommendation === "ready" ? "immediate" : "prepared",
      day_1_3: week1Tasks,
      day_4_7: week2Tasks,
      day_8_14: week3Tasks,
      checkpoints: [
        "Tracking verified",
        "Creatives approved",
        "Budget confirmed",
      ],
      go_no_go_criteria: [
        "Pixel firing correctly",
        "At least 3 creatives ready",
        "Daily budget >= 80 SAR",
      ],
    },
    optimization_rules: {
      kill_conditions: [
        "CPA > 2x target for 3 consecutive days",
        "CTR < 0.5% after 3 days",
        "No conversions after 5 days with > 3k impressions",
      ],
      scale_conditions: [
        "ROAS > 3x for 2 consecutive days",
        "CPA < 0.8x target for 3 days",
        "CTR > 2% sustained",
      ],
      a_b_test_plan: [
        "Creative hook A/B",
        "Audience segment A/B",
        "CTA variant A/B",
      ],
      budget_reallocation_rules: [
        "Reallocate 20% from lowest performer to highest daily",
        "Pause ad sets with < 1% CTR after 48h",
      ],
      creative_refresh_cycle: "Every 7 days",
      audience_expansion_rules: [
        "Expand lookalike from 1% to 3% after 5 conversions",
        "Add interest stacking after CPA stabilizes",
      ],
    },
    risk_register: {
      high_risks:
        riskFlags?.critical?.map((r) => ({
          risk: r.message,
          impact: r.impact ?? "high",
          probability: "high",
          mitigation: r.action,
        })) ?? [],
      medium_risks:
        riskFlags?.warnings?.map((r) => ({
          risk: r.message,
          impact: r.impact ?? "medium",
          probability: "medium",
          mitigation: r.action,
        })) ?? [],
      low_risks: [],
      mitigations: [
        "Daily monitoring checklist",
        "Auto-pause rules configured",
        "Weekly performance review",
      ],
      pre_launch_requirements: preLaunch?.must_fix?.map((f) => f.item) ?? [],
      contingency_plan:
        "If primary channel underperforms, reallocate budget to secondary channel within 24h.",
    },
    raw_blueprint: bp as unknown as Record<string, unknown>,
  };
}

function exportJSON(blueprint: BlueprintData, businessType?: string) {
  const timestamp = new Date()
    .toISOString()
    .replace(/[:.]/g, "-")
    .slice(0, 19);
  const filename = `campaign-blueprint-${businessType ?? "general"}-${timestamp}.json`;
  const blob = new Blob(
    [
      JSON.stringify(
        {
          exported_at: new Date().toISOString(),
          business_type: businessType ?? "unknown",
          blueprint,
        },
        null,
        2
      ),
    ],
    { type: "application/json" }
  );
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportProReadyJSON(
  blueprint: BlueprintData,
  businessType?: string,
  wizardData?: Record<string, unknown>
) {
  const proReady = buildProReadyJSON(blueprint, wizardData);
  const timestamp = new Date()
    .toISOString()
    .replace(/[:.]/g, "-")
    .slice(0, 19);
  const filename = `pro-ready-${businessType ?? "general"}-${timestamp}.json`;
  const blob = new Blob([JSON.stringify(proReady, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportPrintPDF(blueprint: BlueprintData, businessType?: string) {
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    alert("يرجى السماح بفتح النوافذ المنبثقة");
    return;
  }

  const sections = Object.entries(blueprint).filter(
    ([k, v]) =>
      v !== null &&
      v !== undefined &&
      !["blueprint_id", "version", "rule_engine_version", "generated_at", "flags", "debug"].includes(k)
  );

  let contentHtml = "";
  for (const [key, val] of sections) {
    const label = LOCAL_SECTION_LABELS[key] ?? key;
    let content = "";
    if (typeof val === "string") content = val;
    else if (typeof val === "number" || typeof val === "boolean")
      content = String(val);
    else if (Array.isArray(val)) {
      content = val
        .map((i) =>
          typeof i === "string" ? `• ${i}` : JSON.stringify(i, null, 2)
        )
        .join("<br>");
    } else {
      content = JSON.stringify(val, null, 2)
        .replace(/\n/g, "<br>")
        .replace(/ /g, "&nbsp;");
    }

    contentHtml += `
      <div class="section">
        <h2>${label}</h2>
        <div class="section-body">${content}</div>
      </div>
    `;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <title>الخطة الإعلانية - ${businessType ?? ""}</title>
      <style>
        @page { size: A4; margin: 20mm; }
        * { box-sizing: border-box; }
        body {
          font-family: 'Segoe UI', 'Tahoma', 'Arial', sans-serif;
          background: #fff;
          color: #1e293b;
          padding: 0;
          margin: 0;
          line-height: 1.8;
        }
        .header {
          text-align: center;
          border-bottom: 3px solid #7c3aed;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .header h1 {
          color: #7c3aed;
          font-size: 28px;
          margin: 0;
        }
        .header p {
          color: #64748b;
          font-size: 14px;
          margin-top: 8px;
        }
        .section {
          margin-bottom: 20px;
          background: #f8fafc;
          border-radius: 12px;
          padding: 16px;
          border-right: 4px solid #7c3aed;
          page-break-inside: avoid;
        }
        .section h2 {
          color: #7c3aed;
          font-size: 16px;
          margin: 0 0 10px 0;
          font-weight: 600;
        }
        .section-body {
          color: #334155;
          font-size: 13px;
          white-space: pre-wrap;
          word-break: break-word;
        }
        .no-print {
          display: none !important;
        }
        @media print {
          body { background: #fff; }
          .section { break-inside: avoid; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>الخطة الإعلانية</h1>
        <p>${businessType ?? "—"} | ${new Date().toLocaleDateString("ar-SA")}</p>
      </div>
      ${contentHtml}
      <script>
        window.onload = function() {
          setTimeout(function() {
            window.print();
          }, 500);
        };
      </script>
    </body>
    </html>
  `);

  printWindow.document.close();
}

export function BlueprintExporter({
  blueprint,
  businessType,
  wizardData,
}: BlueprintExporterProps) {
  const [jsonDone, setJsonDone] = useState(false);
  const [proDone, setProDone] = useState(false);

  const handleJSON = () => {
    exportJSON(blueprint, businessType);
    setJsonDone(true);
    setTimeout(() => setJsonDone(false), 2000);
  };

  const handleProJSON = () => {
    exportProReadyJSON(blueprint, businessType, wizardData);
    setProDone(true);
    setTimeout(() => setProDone(false), 2000);
  };

  const handlePDF = () => {
    exportPrintPDF(blueprint, businessType);
  };

  return (
    <div className="flex gap-3 flex-wrap justify-center" dir="rtl">
      <button
        onClick={handleJSON}
        className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200
          ${jsonDone ? "bg-green-900/40 border-green-700 text-green-400" : "bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 hover:border-gray-600 hover:text-white"}`}
      >
        {jsonDone ? "✓ تم التنزيل" : "📥 تنزيل JSON"}
      </button>

      <button
        onClick={handleProJSON}
        className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200
          ${proDone ? "bg-green-900/40 border-green-700 text-green-400" : "bg-indigo-900/40 border-indigo-700 text-indigo-300 hover:bg-indigo-800/40 hover:border-indigo-600 hover:text-indigo-200"}`}
      >
        {proDone ? "✓ تم التنزيل" : "📦 Pro-Ready JSON"}
      </button>

      <button
        onClick={handlePDF}
        className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200 bg-violet-900/40 border-violet-700 text-violet-300 hover:bg-violet-800/40 hover:border-violet-600 hover:text-violet-200"
      >
        📄 فتح للطباعة / PDF
      </button>
    </div>
  );
}