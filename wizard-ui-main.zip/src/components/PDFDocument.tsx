import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";
import {
  SECTION_LABELS,
  SECTION_ICONS,
  SECTION_COLORS,
  SECTION_ORDER,
  type BlueprintData,
} from "@/lib/blueprint-types";

Font.register({
  family: "Cairo",
  src: "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/cairo/Cairo%5Bslnt,wght%5D.ttf",
  fontStyle: "normal",
  fontWeight: "normal",
});

Font.register({
  family: "Cairo",
  src: "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/cairo/Cairo%5Bslnt,wght%5D.ttf",
  fontStyle: "normal",
  fontWeight: "bold",
});

const COLORS = {
  primary: "#7c3aed",
  primaryDark: "#5b21b6",
  primaryLight: "#ede9fe",
  text: "#1e293b",
  textLight: "#475569",
  textMuted: "#64748b",
  white: "#ffffff",
  border: "#e2e8f0",
  coverGradientStart: "#f5f3ff",
  coverGradientEnd: "#ede9fe",
  green: "#16a34a",
  yellow: "#d97706",
  red: "#dc2626",
};

const styles = StyleSheet.create({
  page: {
    padding: 40,
    paddingTop: 35,
    paddingBottom: 50,
    fontFamily: "Cairo",
    fontSize: 11,
    color: COLORS.text,
    backgroundColor: COLORS.white,
  },
  coverPage: {
    padding: 0,
    backgroundColor: COLORS.coverGradientStart,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  coverContent: {
    alignItems: "center",
    padding: 60,
  },
  coverBadge: {
    backgroundColor: COLORS.primary,
    color: COLORS.white,
    paddingHorizontal: 24,
    paddingVertical: 8,
    borderRadius: 999,
    fontSize: 11,
    fontWeight: "bold",
    letterSpacing: 0.5,
    marginBottom: 30,
  },
  coverTitle: {
    fontSize: 36,
    fontWeight: "bold",
    color: COLORS.primaryDark,
    textAlign: "center",
    marginBottom: 8,
    lineHeight: 1.3,
  },
  coverSubtitle: {
    fontSize: 18,
    color: COLORS.primary,
    fontWeight: "bold",
    marginBottom: 40,
    textAlign: "center",
  },
  coverMeta: {
    flexDirection: "row-reverse",
    gap: 32,
    marginTop: 20,
  },
  coverMetaItem: {
    alignItems: "center",
  },
  coverMetaLabel: {
    fontSize: 10,
    color: "#8b5cf6",
    fontWeight: "bold",
    marginBottom: 4,
  },
  coverMetaValue: {
    fontSize: 14,
    color: COLORS.primaryDark,
    fontWeight: "bold",
  },
  coverFooter: {
    position: "absolute",
    bottom: 40,
    fontSize: 10,
    color: "#a78bfa",
  },
  coverDecoration: {
    position: "absolute",
    top: -100,
    right: -100,
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: "rgba(124,58,237,0.06)",
  },
  readinessBox: {
    flexDirection: "row-reverse",
    gap: 16,
    marginTop: 24,
    padding: 16,
    backgroundColor: "rgba(255,255,255,0.6)",
    borderRadius: 12,
    border: "1px solid rgba(124,58,237,0.15)",
  },
  readinessItem: {
    alignItems: "center",
    minWidth: 80,
  },
  readinessLabel: {
    fontSize: 9,
    color: "#8b5cf6",
    fontWeight: "bold",
    marginBottom: 4,
  },
  readinessValue: {
    fontSize: 16,
    fontWeight: "bold",
  },
  tocPage: {
    padding: 40,
    paddingTop: 35,
    paddingBottom: 50,
  },
  tocTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: COLORS.primaryDark,
    marginBottom: 24,
    paddingBottom: 12,
    borderBottom: `3px solid ${COLORS.primary}`,
  },
  tocGrid: {
    flexDirection: "column",
    gap: 10,
  },
  tocItem: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 12,
    padding: 14,
    backgroundColor: "#f8fafc",
    borderRadius: 10,
    borderRight: `3px solid #ddd6fe`,
  },
  tocNum: {
    fontSize: 11,
    fontWeight: "bold",
    color: "#a78bfa",
    backgroundColor: "#ede9fe",
    width: 28,
    height: 28,
    borderRadius: 6,
    textAlign: "center",
    lineHeight: 28,
  },
  tocIcon: {
    fontSize: 16,
  },
  tocLabel: {
    fontSize: 12,
    fontWeight: "bold",
    color: COLORS.primaryDark,
    flex: 1,
    textAlign: "right",
  },
  summaryBox: {
    backgroundColor: COLORS.primaryLight,
    border: `2px solid #c4b5fd`,
    borderRadius: 14,
    padding: 20,
    marginBottom: 24,
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 16,
  },
  summaryItem: {
    flex: 1,
    minWidth: 120,
    alignItems: "center",
  },
  summaryIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 10,
    color: COLORS.primary,
    fontWeight: "bold",
  },
  summaryValue: {
    fontSize: 16,
    color: COLORS.primaryDark,
    fontWeight: "bold",
    marginTop: 2,
  },
  section: {
    marginBottom: 16,
    borderRadius: 12,
    padding: 16,
    pageBreakInside: "avoid",
  },
  sectionHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
    marginBottom: 10,
    paddingBottom: 8,
    borderBottom: `1px dashed rgba(0,0,0,0.08)`,
  },
  sectionIcon: {
    fontSize: 18,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "bold",
    flex: 1,
    textAlign: "right",
  },
  sectionBody: {
    color: COLORS.textLight,
    fontSize: 11,
    lineHeight: 1.8,
    textAlign: "right",
  },
  bulletItem: {
    flexDirection: "row-reverse",
    gap: 8,
    marginBottom: 4,
  },
  bulletDot: {
    color: COLORS.primary,
    fontSize: 11,
    lineHeight: 1.8,
  },
  bulletText: {
    flex: 1,
    textAlign: "right",
    lineHeight: 1.8,
  },
  pageNumber: {
    position: "absolute",
    bottom: 20,
    left: 0,
    right: 0,
    textAlign: "center",
    fontSize: 9,
    color: COLORS.textMuted,
  },
  pageHeader: {
    position: "absolute",
    top: 15,
    left: 40,
    right: 40,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    borderBottom: `1px solid ${COLORS.border}`,
    paddingBottom: 8,
  },
  pageHeaderText: {
    fontSize: 8,
    color: COLORS.textMuted,
  },
});

function formatValue(val: unknown): string {
  if (val === null || val === undefined) return "—";
  if (typeof val === "string") return val;
  if (typeof val === "number" || typeof val === "boolean") return String(val);
  if (Array.isArray(val)) {
    return val
      .map((item) => (typeof item === "string" ? item : JSON.stringify(item)))
      .join("\n");
  }
  return JSON.stringify(val, null, 2);
}

function isArrayOfStrings(val: unknown): val is string[] {
  return Array.isArray(val) && val.every((i) => typeof i === "string");
}

function BulletList({ items }: { items: string[] }) {
  return (
    <View>
      {items.map((item, i) => (
        <View key={i} style={styles.bulletItem}>
          <Text style={styles.bulletDot}>•</Text>
          <Text style={styles.bulletText}>{item}</Text>
        </View>
      ))}
    </View>
  );
}

function SectionContent({ val }: { val: unknown }) {
  if (val === null || val === undefined) {
    return <Text style={styles.sectionBody}>—</Text>;
  }
  if (typeof val === "string") {
    return <Text style={styles.sectionBody}>{val}</Text>;
  }
  if (typeof val === "number" || typeof val === "boolean") {
    return <Text style={styles.sectionBody}>{String(val)}</Text>;
  }
  if (isArrayOfStrings(val)) {
    return <BulletList items={val} />;
  }
  if (Array.isArray(val)) {
    return (
      <BulletList
        items={val.map((item) =>
          typeof item === "string" ? item : JSON.stringify(item)
        )}
      />
    );
  }
  const obj = val as Record<string, unknown>;
  return (
    <View>
      {Object.entries(obj).map(([k, v]) => (
        <View key={k} style={{ marginBottom: 6 }}>
          <Text
            style={{
              fontWeight: "bold",
              fontSize: 10,
              color: COLORS.primaryDark,
              marginBottom: 2,
              textAlign: "right",
            }}
          >
            {k}:
          </Text>
          <Text style={styles.sectionBody}>{formatValue(v)}</Text>
        </View>
      ))}
    </View>
  );
}

function CoverPage({
  businessType,
  totalBudget,
  duration,
  executiveSummary,
}: {
  businessType?: string;
  totalBudget: number;
  duration: number;
  executiveSummary?: BlueprintData["executive_summary"];
}) {
  const today = new Date().toLocaleDateString("ar-SA", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const readinessColor =
    executiveSummary?.readiness_level === "strong"
      ? COLORS.green
      : executiveSummary?.readiness_level === "moderate"
      ? COLORS.yellow
      : COLORS.red;

  const riskColor =
    executiveSummary?.risk_level === "low"
      ? COLORS.green
      : executiveSummary?.risk_level === "medium"
      ? COLORS.yellow
      : COLORS.red;

  const launchAr =
    executiveSummary?.launch_recommendation === "ready"
      ? "جاهز للإطلاق ✅"
      : executiveSummary?.launch_recommendation === "ready_with_fixes"
      ? "جاهز بعد الإصلاحات ⚡"
      : "غير جاهز للإطلاق ❌";

  const launchColor =
    executiveSummary?.launch_recommendation === "ready"
      ? COLORS.green
      : executiveSummary?.launch_recommendation === "ready_with_fixes"
      ? COLORS.yellow
      : COLORS.red;

  return (
    <Page size="A4" style={styles.coverPage}>
      <View style={styles.coverDecoration} />
      <View style={styles.coverContent}>
        <Text style={styles.coverBadge}>📋 CAMPAIGN BLUEPRINT</Text>
        <Text style={styles.coverTitle}>
          الخطة الإعلانية{"\n"}الشاملة
        </Text>
        <Text style={styles.coverSubtitle}>{businessType ?? "عام"}</Text>

        <View style={styles.coverMeta}>
          <View style={styles.coverMetaItem}>
            <Text style={styles.coverMetaLabel}>تاريخ الإعداد</Text>
            <Text style={styles.coverMetaValue}>{today}</Text>
          </View>
          <View style={styles.coverMetaItem}>
            <Text style={styles.coverMetaLabel}>مدة الحملة</Text>
            <Text style={styles.coverMetaValue}>{duration} يوم</Text>
          </View>
          {totalBudget > 0 && (
            <View style={styles.coverMetaItem}>
              <Text style={styles.coverMetaLabel}>الميزانية</Text>
              <Text style={styles.coverMetaValue}>
                {totalBudget.toLocaleString("ar-SA")} ر.س
              </Text>
            </View>
          )}
        </View>

        {executiveSummary && (
          <View style={styles.readinessBox}>
            <View style={styles.readinessItem}>
              <Text style={styles.readinessLabel}>جاهزية الإطلاق</Text>
              <Text
                style={[styles.readinessValue, { color: readinessColor }]}
              >
                {executiveSummary.readiness_score}/100
              </Text>
            </View>
            <View style={styles.readinessItem}>
              <Text style={styles.readinessLabel}>مستوى المخاطر</Text>
              <Text style={[styles.readinessValue, { color: riskColor }]}>
                {executiveSummary.risk_score}/100
              </Text>
            </View>
            <View style={styles.readinessItem}>
              <Text style={styles.readinessLabel}>التوصية</Text>
              <Text
                style={[
                  styles.readinessValue,
                  { color: launchColor, fontSize: 12 },
                ]}
              >
                {launchAr}
              </Text>
            </View>
            <View style={styles.readinessItem}>
              <Text style={styles.readinessLabel}>تاريخ الإطلاق المتوقع</Text>
              <Text style={[styles.readinessValue, { fontSize: 12 }]}>
                {executiveSummary.estimated_launch_date}
              </Text>
            </View>
          </View>
        )}
      </View>
      <Text style={styles.coverFooter}>
        تم إعدادها بواسطة Campaign Engine Builder
      </Text>
    </Page>
  );
}

function TOCPage({ sections }: { sections: string[] }) {
  return (
    <Page size="A4" style={styles.tocPage}>
      <Text style={styles.tocTitle}>📑 محتويات الخطة</Text>
      <View style={styles.tocGrid}>
        {sections.map((key, idx) => {
          const label = SECTION_LABELS[key] ?? key;
          const icon = SECTION_ICONS[key] ?? "📋";
          return (
            <View key={key} style={styles.tocItem}>
              <Text style={styles.tocNum}>
                {String(idx + 1).padStart(2, "0")}
              </Text>
              <Text style={styles.tocIcon}>{icon}</Text>
              <Text style={styles.tocLabel}>{label}</Text>
            </View>
          );
        })}
      </View>
      <Text
        style={styles.pageNumber}
        render={({ pageNumber, totalPages }) =>
          `${pageNumber} / ${totalPages}`
        }
        fixed
      />
    </Page>
  );
}

function ContentPages({
  blueprint,
  businessType,
  totalBudget,
  duration,
  segmentCount,
}: {
  blueprint: BlueprintData;
  businessType?: string;
  totalBudget: number;
  duration: number;
  segmentCount: number;
}) {
  const sections = SECTION_ORDER.filter(
    (key) => blueprint[key] !== null && blueprint[key] !== undefined
  );

  const primaryObjective =
    blueprint.strategy_summary?.recommended_objective?.value
      ? String(blueprint.strategy_summary.recommended_objective.value).slice(0, 20) + "..."
      : "زيادة المبيعات";

  return (
    <Page size="A4" style={styles.page}>
      <View style={styles.pageHeader} fixed>
        <Text style={styles.pageHeaderText}>
          الخطة الإعلانية | {businessType ?? "عام"}
        </Text>
        <Text style={styles.pageHeaderText}>Campaign Engine Builder</Text>
      </View>

      <View style={styles.summaryBox}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryIcon}>🎯</Text>
          <Text style={styles.summaryLabel}>الهدف الرئيسي</Text>
          <Text style={styles.summaryValue}>{primaryObjective}</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryIcon}>👥</Text>
          <Text style={styles.summaryLabel}>الجمهور</Text>
          <Text style={styles.summaryValue}>{segmentCount} شريحة</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryIcon}>💰</Text>
          <Text style={styles.summaryLabel}>الميزانية</Text>
          <Text style={styles.summaryValue}>
            {totalBudget > 0
              ? totalBudget.toLocaleString("ar-SA") + " ر.س"
              : "غير محدد"}
          </Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryIcon}>📅</Text>
          <Text style={styles.summaryLabel}>المدة</Text>
          <Text style={styles.summaryValue}>{duration} يوم</Text>
        </View>
      </View>

      {sections.map((key) => {
        const label = SECTION_LABELS[key] ?? key;
        const icon = SECTION_ICONS[key] ?? "📋";
        const colors = SECTION_COLORS[key] ?? {
          bg: "#f8fafc",
          border: "#7c3aed",
          text: "#1e293b",
          light: "#f1f5f9",
        };
        const val = blueprint[key];

        return (
          <View
            key={key}
            style={[
              styles.section,
              {
                backgroundColor: colors.bg,
                borderRight: `5px solid ${colors.border}`,
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionIcon}>{icon}</Text>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                {label}
              </Text>
            </View>
            <SectionContent val={val} />
          </View>
        );
      })}

      <Text
        style={styles.pageNumber}
        render={({ pageNumber, totalPages }) =>
          `${pageNumber} / ${totalPages}`
        }
        fixed
      />
    </Page>
  );
}

interface BlueprintPDFProps {
  blueprint: BlueprintData;
  businessType?: string;
}

export function BlueprintPDF({ blueprint, businessType }: BlueprintPDFProps) {
  const budget = blueprint.budget_split;
  const dailyBudget = budget?.daily_budget?.value?.recommended ?? 0;
  const totalBudget = dailyBudget * 14;
  const duration = 14;

  const segmentCount = Array.isArray(
    blueprint.audience_structure?.segments
  )
    ? blueprint.audience_structure.segments.length
    : 1;

  const sections = SECTION_ORDER.filter(
    (key) => blueprint[key] !== null && blueprint[key] !== undefined
  );

  return (
    <Document
      title={`الخطة الإعلانية — ${businessType ?? "عام"}`}
      author="Campaign Engine Builder"
      subject="Campaign Blueprint"
      language="ar"
    >
      <CoverPage
        businessType={businessType}
        totalBudget={totalBudget}
        duration={duration}
        executiveSummary={blueprint.executive_summary}
      />
      <TOCPage sections={sections} />
      <ContentPages
        blueprint={blueprint}
        businessType={businessType}
        totalBudget={totalBudget}
        duration={duration}
        segmentCount={segmentCount}
      />
    </Document>
  );
}